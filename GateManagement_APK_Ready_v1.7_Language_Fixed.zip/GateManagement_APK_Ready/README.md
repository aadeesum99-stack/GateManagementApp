# Gate Management APK - Updated v1.1

Offline Android WebView project for Gate Entry & Exit Management.

## Updates in v1.1
- Fixed report downloads in the Android APK: CSV and Word reports are saved to `Downloads/Gate Management`.
- Added Word `.docx` bulk-import option in Reports.
- Word import reads tables and adds Person and Vehicle records.
- Added Android file picker support for Word upload.
- Existing localStorage data is preserved when updating the APK without uninstalling the old app.

## Word import format
Use a `.docx` Word document with one or more tables. The first row should contain headings such as:

`Type | QID | Name | Army No | Rank | Vehicle No | Driver | Vehicle Type | Entry Date | Entry Time | Exit Date | Exit Time`

For person rows, use QID/Name/Army No/Rank. For vehicle rows, use Vehicle No/Driver/Vehicle Type. Type may be `PERSON` or `VEHICLE`.

## Build
This project is intended to be built by GitHub Actions using Android SDK 35 and Gradle 8.10.2.
